import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getBots } from "../actions"

export const BotSelection = async () => {
  const bots = await getBots()

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {bots.map((bot) => (
        <Link href={`/chat/${bot.id}`} key={bot.id}>
          <Card className="cursor-pointer hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle>{bot.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p>{bot.description}</p>
            </CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}

