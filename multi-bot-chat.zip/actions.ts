"use server"
import type { Bot } from "./types"
import { openai } from "@ai-sdk/openai"
import { streamText } from "ai"

const bots: Bot[] = [
  {
    id: "schedule",
    name: "日程調整Bot",
    description: "日程調整を手伝います",
    systemPrompt: "あなたは日程調整の専門家です。ユーザーの日程調整を手伝ってください。",
  },
  {
    id: "research",
    name: "リサーチBot",
    description: "調査研究を支援します",
    systemPrompt: "あなたは研究調査の専門家です。ユーザーの調査を手伝ってください。",
  },
]

export const getBots = async (): Promise<Bot[]> => {
  return bots
}

export const getBot = async (id: string): Promise<Bot | undefined> => {
  return bots.find((bot) => bot.id === id)
}

export const sendMessage = async (botId: string, content: string) => {
  const bot = await getBot(botId)
  if (!bot) {
    throw new Error("Bot not found")
  }

  const result = streamText({
    model: openai("gpt-4-turbo"),
    messages: [
      { role: "system", content: bot.systemPrompt },
      { role: "user", content },
    ],
  })

  return result.toDataStreamResponse()
}

