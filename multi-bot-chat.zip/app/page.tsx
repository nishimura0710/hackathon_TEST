import { Suspense } from "react"
import { BotSelection } from "../components/BotSelection"

const AIBotManagementApp = () => {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">{"AIチャットボット管理画面"}</h1>
      <Suspense fallback={<div>{"ボット一覧を読み込み中..."}</div>}>
        <BotSelection />
      </Suspense>
    </div>
  )
}

export default AIBotManagementApp

