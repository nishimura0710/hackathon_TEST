import { Suspense } from "react"
import { notFound } from "next/navigation"
import { ChatInterface } from "../../../components/ChatInterface"
import { getBot } from "../../../actions"

const ChatPage = async ({ params }: { params: { botId: string } }) => {
  const bot = await getBot(params.botId)

  if (!bot) {
    notFound()
  }

  return (
    <div className="container mx-auto p-4">
      <Suspense fallback={<div>{"チャットを読み込み中..."}</div>}>
        <ChatInterface bot={bot} />
      </Suspense>
    </div>
  )
}

export default ChatPage

