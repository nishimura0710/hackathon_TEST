import type { NextRequest } from "next/server"
import { sendMessage } from "../../../../actions"

export const POST = async (req: NextRequest, { params }: { params: { botId: string } }) => {
  const { messages } = await req.json()
  const lastMessage = messages[messages.length - 1]

  if (lastMessage.role !== "user") {
    return new Response("Invalid request", { status: 400 })
  }

  return sendMessage(params.botId, lastMessage.content)
}

